var mg = require('mongoose')
var bookschema = new mg.Schema({
    title : {type:String},
    author : {type:String}
})
var Book = new mg.model('Book',bookschema) 
module.exports = Book