var express = require('express')
var bp = require('body-parser')
var mg = require('mongoose')
var Book = require('./model')

var app = express()
app.use(bp.urlencoded({ extended: true }))
app.use(express.json())
var dt = mg.connect('mongodb://localhost:27017/book').then(() => { console.log('mongodb connected!') }).catch((error) => { console.log(error) })

// GET Api for READ items
app.get('/book', async (req, res) => { const book = await Book.find(); res.status(200).json({ success: true, book }) })

// POST Api for CREATE items
app.post('/book', async (req, res) => {
    const { title, author } = req.body
    const book = await Book.create({ title, author })
    res.status(201).json({ success: true, book });
})

// PUT Api for UPDATE items
app.put('/book/:id', async (req, res) => {
    let book = await Book.findById(req.params.id);
    if (!book) {
        res.status(404).json({
            success: false
        })
    }
    book = await Book.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        useFindAndModify: false,
        runValidators: true
    });
    res.status(200).json({
        success: true,
        book
    });
})

// DELETE Api for DELETE items
app.delete('/book/:id', async (req, res) => {
    const book = await Book.findById(req.params.id);
    if (!book) {
        res.status(404).json({
            success: false
        })
    }
    await book.remove();
    res.status(200).json({
        success: true, message: "Deleted successfully"
    })
})
app.listen(8080)