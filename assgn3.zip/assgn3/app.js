const express = require("express");
const fs = require("fs");

const app = express();

app.use(express.urlencoded({ extended: true }));

const student_details = {
	student_name: "",
	student_id: "",
	student_age: "",
	student_college_name: "",
	student_cgpa: "",
};

app.get("/", function (req, res) {
	res.send("Welcome to the Server");
});

app.get("/login", function (req, res) {
	fs.readFile("index.html", function (err, data) {
		res.writeHead(200, { "Content-Type": "text/html" });
		res.write(data);
		res.end();
	});
});

app.post("/submit", function (req, res) {
	const student_id = req.body.sid;
	const fileExists = fs.existsSync(`${student_id + ".json"}`);

	if (fileExists) {
		fs.readFile("old_details.html", function (err, data) {
			res.writeHead(200, { "Content-Type": "text/html" });
			res.write(data);
			res.end();
		});
	} else {
		fs.readFile("new_details.html", function (err, data) {
			res.writeHead(200, { "Content-Type": "text/html" });
			res.write(data);
			res.end();
		});
	}
});

app.post("/new_details", function (req, res) {
	const student_name = req.body.name;
	const student_id = req.body.sid;
	const student_age = req.body.age;
	const student_college_name = req.body.college;
	const student_cgpa = req.body.cgpa;

	student_details.student_name = student_name;
	student_details.student_id = student_id;
	student_details.student_age = student_age;
	student_details.student_college_name = student_college_name;
	student_details.student_cgpa = student_cgpa;

	fs.writeFile(
		`${student_id + ".json"}`,
		JSON.stringify(student_details),
		function (err) {
			if (err) {
				console.log(err);
			} else {
				res.send(
					"New file created successfully with the given details of the student"
				);
			}
		}
	);
});

app.post("/old_details", function (req, res) {
	const student_name = req.body.name;
	const student_id = req.body.sid;
	const student_age = req.body.age;
	const student_college_name = req.body.college;
	const student_cgpa = req.body.cgpa;
	const button_clicked = req.body.button;

	if (button_clicked == "close") {
		res.redirect("/login");
	}

	student_details.student_name = student_name;
	student_details.student_id = student_id;
	student_details.student_age = student_age;
	student_details.student_college_name = student_college_name;
	student_details.student_cgpa = student_cgpa;

	fs.writeFile(
		`${student_id + ".json"}`,
		JSON.stringify(student_details),
		function (err) {
			if (err) {
				console.log(err);
			} else {
				res.send(
					"File updated successfully with the given details of the student"
				);
			}
		}
	);
});

app.listen(8000, function () {
	console.log("Server is up and running on port 8000");
});