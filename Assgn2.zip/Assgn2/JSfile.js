const express = require('express')
var fs = require('fs');
var cookieParser = require('cookie-parser')

const app = express();
app.use(cookieParser())


app.get("/", (req, res) => {
    fs.readFile('./view/index.html', function (err, data) {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write(data);
        res.send()
    });
})

app.get('/getCalculator', (req, res) => {
    var type = req.query.cal;

    if (type == 'simple') {
        fs.readFile('./view/sCal.html', function (err, data) {
            res.writeHead(200, { 'Content-Type': 'text/html' });
            var result = data
            if (req.query.result) {
                var cookies = req.cookies.simpleCalCookie
                if (cookies != "" && cookies != undefined) {
                    var cookieList = cookies.split(':');
                    console.log(cookieList.length);
                    var cookieStr = "";
                    result += "<center><h1>LAST RESULT: " + cookieList[0] + "</h1></center>"

                    result += "<center><h2>Last 5 Calculation</h2></center>"
                    if (cookieList.length < 5) {
                        for (var i = 0; i < cookieList.length; i++) {
                            cookieStr += '<center>' + (i + 1) + ". " + cookieList[i] + '</center><br>'
                        }
                    } else {
                        for (var i = 0; i < 5; i++) {
                            cookieStr += '<center>' + (i + 1) + ". " + cookieList[i] + '</center><br>'
                        }
                    }
                    console.log(cookieStr);
                    result += cookieStr
                }

            }
            res.write(result);
            res.send()
        });
    }
    else {
        fs.readFile('./view/scCal.html', function (err, data) {
            res.writeHead(200, { 'Content-Type': 'text/html' });
            var result = data
            if (req.query.result) {
                var cookies = req.cookies.sciCalCookie
                if (cookies != "" && cookies != undefined) {
                    var cookieList = cookies.split(':');
                    console.log(cookieList.length);
                    var cookieStr = "";
                    result += "<center><h1>LAST RESULT: " + cookieList[0] + "</h1></center>"

                    result += "<center><h2>Last 5 Calculation</h2></center>"
                    if (cookieList.length < 5) {
                        for (var i = 0; i < cookieList.length; i++) {
                            cookieStr += '<center>' + (i + 1) + ". " + cookieList[i] + '</center><br>'
                        }
                    } else {
                        for (var i = 0; i < 5; i++) {
                            cookieStr += '<center>' + (i + 1) + ". " + cookieList[i] + '</center><br>'
                        }
                    }
                    console.log(cookieStr);
                    result += cookieStr
                }

            }
            res.write(result);
            res.send()
        });
    }

})


app.get("/doSimpleCal", (req, res) => {
    var num1 = req.query.val1;
    var num2 = req.query.val2;
    var op = req.query.type;
    if (op == '+') {
        doSimpleCal(num1, num2, '+', req, res)
    } else if (op == '-') {
        doSimpleCal(num1, num2, '-', req, res)
    } else if (op == '*') {
        doSimpleCal(num1, num2, '*', req, res)
    } else if (op == '/') {
        doSimpleCal(num1, num2, '/', req, res)
    }
})

function doSimpleCal(num1, num2, op, req, res) {
    if (op == '+') {
        var result = num1 + " + " + num2 + " = " + (parseInt(num1) + parseInt(num2))
    } else if (op == '-') {
        var result = num1 + " - " + num2 + " = " + (parseInt(num1) - parseInt(num2))
    } else if (op == '*') {
        var result = num1 + " * " + num2 + " = " + (parseInt(num1) * parseInt(num2))
    } else if (op == '/') {
        var result = num1 + " / " + num2 + " = " + (parseInt(num1) / parseInt(num2))
    }
    var cookies = req.cookies.simpleCalCookie;
    if (cookies) {
        cookies = result + ":" + cookies
    } else {
        cookies = result
    }
    res.cookie('simpleCalCookie', cookies)
    res.data = result
    res.redirect('/getCalculator?cal=simple&result=true')
}

app.get("/doScintiCal", (req, res) => {
    var num1 = req.query.val1;
    var op = req.query.type;
    if (op == 'sin') {
        var result = 'sin(' + num1 + ') = ' + Math.sin(num1);
    } else if (op == 'cos') {
        var result = 'cos(' + num1 + ') = ' + Math.cos(num1);
    } else if (op == 'tan') {
        var result = 'tan(' + num1 + ') = ' + Math.tan(num1);
    } else if (op == 'log') {
        var result = 'log(' + num1 + ') = ' + Math.log(num1);
    }


    var cookies = req.cookies.sciCalCookie;
    if (cookies) {
        cookies = result + ":" + cookies
    } else {
        cookies = result
    }

    res.cookie('sciCalCookie', cookies)
    res.data = result
    res.redirect('/getCalculator?cal=scintific&result=true')
});
app.listen(3000);